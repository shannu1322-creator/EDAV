import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'social_media_posts.csv'
OUT = ROOT / 'outputs'
OUT.mkdir(exist_ok=True)
def load_data(path=DATA):
    df = pd.read_csv(path, parse_dates=['post_date'])
    required = {'post_id','platform','content_type','reach','impressions','likes','comments','shares','saves'}
    missing = required - set(df.columns)
    if missing: raise ValueError(f'Missing required columns: {sorted(missing)}')
    df['engagements'] = df[['likes','comments','shares','saves']].sum(axis=1)
    df['engagement_rate'] = (df['engagements'] / df['reach'].replace(0, pd.NA) * 100).fillna(0)
    return df
def summarize(df):
    print('ROWS:', len(df))
    print('\nOverall metrics')
    print(df[['reach','impressions','engagements','engagement_rate']].describe().round(2))
    print('\nPlatform performance')
    print(df.groupby('platform').agg(posts=('post_id','count'),avg_engagement_rate=('engagement_rate','mean'),total_engagements=('engagements','sum')).sort_values('avg_engagement_rate',ascending=False).round(2))
    print('\nContent performance')
    print(df.groupby('content_type').agg(posts=('post_id','count'),avg_engagement_rate=('engagement_rate','mean'),avg_reach=('reach','mean')).sort_values('avg_engagement_rate',ascending=False).round(2))
def make_charts(df):
    sns.set_theme(style='whitegrid')
    charts=[(df.groupby('platform').engagement_rate.mean().sort_values(ascending=False),'Average engagement rate by platform','platform_engagement.png'),(df.groupby('content_type').engagement_rate.mean().sort_values(ascending=False),'Average engagement rate by content type','content_engagement.png'),(df.groupby('day_of_week').engagement_rate.mean().reindex(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']),'Engagement rate by day','weekday_engagement.png'),(df.groupby('post_hour').engagement_rate.mean(),'Engagement rate by posting hour','hourly_engagement.png')]
    for series,title,filename in charts:
        fig,ax=plt.subplots(figsize=(9,5)); categorical=not pd.api.types.is_numeric_dtype(series.index.dtype)
        series.plot(kind='bar', ax=ax) if categorical else series.plot(kind='line', marker='o', ax=ax)
        ax.set_title(title); ax.set_ylabel('Average engagement rate (%)'); ax.set_xlabel(''); plt.xticks(rotation=30,ha='right'); plt.tight_layout(); fig.savefig(OUT/filename,dpi=160); plt.close(fig)
    corr=df[['reach','impressions','likes','comments','shares','saves','hashtag_count','engagement_rate']].corr(numeric_only=True)
    fig,ax=plt.subplots(figsize=(9,7)); sns.heatmap(corr,annot=True,fmt='.2f',cmap='coolwarm',center=0,ax=ax); ax.set_title('Engagement metrics correlation'); plt.tight_layout(); fig.savefig(OUT/'correlation_heatmap.png',dpi=160); plt.close(fig)
    df.groupby('platform').agg(posts=('post_id','count'),avg_engagement_rate=('engagement_rate','mean'),total_engagements=('engagements','sum')).sort_values('avg_engagement_rate',ascending=False).to_csv(OUT/'platform_summary.csv')
    df.groupby('content_type').agg(posts=('post_id','count'),avg_engagement_rate=('engagement_rate','mean'),avg_reach=('reach','mean')).sort_values('avg_engagement_rate',ascending=False).to_csv(OUT/'content_summary.csv')
if __name__=='__main__':
    data=load_data(); summarize(data); make_charts(data); print(f'\nCharts and summaries saved in: {OUT}')
