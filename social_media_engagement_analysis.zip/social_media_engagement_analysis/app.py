import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="Social Media Engagement Analysis", page_icon="📊", layout="wide")
ROOT=Path(__file__).resolve().parent
@st.cache_data
def get_data():
    d=pd.read_csv(ROOT/"data"/"social_media_posts.csv",parse_dates=["post_date"])
    d["engagements"]=d[["likes","comments","shares","saves"]].sum(axis=1)
    d["engagement_rate"]=d["engagements"]/d["reach"].replace(0, pd.NA)*100
    return d

df=get_data()
st.title("📊 Social Media Engagement Pattern Analysis")
st.caption("Explore how platform, content format and publishing time relate to audience engagement.")
with st.sidebar:
    st.header("Filters")
    selected_platforms=st.multiselect("Platform",sorted(df.platform.unique()),default=sorted(df.platform.unique()))
    selected_types=st.multiselect("Content type",sorted(df.content_type.unique()),default=sorted(df.content_type.unique()))
    date_min,date_max=df.post_date.min().date(),df.post_date.max().date()
    date_range=st.date_input("Date range",value=(date_min,date_max),min_value=date_min,max_value=date_max)
    if len(date_range)==2:
        mask=(df.post_date.dt.date>=date_range[0])&(df.post_date.dt.date<=date_range[1])
    else: mask=pd.Series(True,index=df.index)
    filtered=df[df.platform.isin(selected_platforms)&df.content_type.isin(selected_types)&mask]
if filtered.empty:
    st.warning("No posts match these filters. Adjust the selections in the sidebar.")
    st.stop()

c1,c2,c3,c4=st.columns(4)
c1.metric("Posts",f"{len(filtered):,}")
c2.metric("Total engagements",f"{filtered.engagements.sum():,}")
c3.metric("Average engagement rate",f"{filtered.engagement_rate.mean():.2f}%")
c4.metric("Average reach",f"{filtered.reach.mean():,.0f}")
st.divider()
left,right=st.columns(2)
with left:
    p=filtered.groupby("platform",as_index=False).engagement_rate.mean().sort_values("engagement_rate",ascending=False)
    st.plotly_chart(px.bar(p,x="platform",y="engagement_rate",title="Average engagement rate by platform",labels={"engagement_rate":"Engagement rate (%)"}),use_container_width=True)
with right:
    t=filtered.groupby("content_type",as_index=False).engagement_rate.mean().sort_values("engagement_rate",ascending=False)
    st.plotly_chart(px.bar(t,x="content_type",y="engagement_rate",title="Average engagement rate by content type",labels={"engagement_rate":"Engagement rate (%)"}),use_container_width=True)
left,right=st.columns(2)
with left:
    h=filtered.groupby("post_hour",as_index=False).engagement_rate.mean()
    st.plotly_chart(px.line(h,x="post_hour",y="engagement_rate",markers=True,title="Engagement by posting hour",labels={"post_hour":"Hour of day","engagement_rate":"Engagement rate (%)"}),use_container_width=True)
with right:
    w=filtered.groupby("day_of_week",as_index=False).engagement_rate.mean()
    order=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    w["day_of_week"]=pd.Categorical(w.day_of_week,categories=order,ordered=True); w=w.sort_values("day_of_week")
    st.plotly_chart(px.bar(w,x="day_of_week",y="engagement_rate",title="Engagement by day of week",labels={"day_of_week":"Day","engagement_rate":"Engagement rate (%)"}),use_container_width=True)
st.subheader("Engagement breakdown")
breakdown=filtered[["likes","comments","shares","saves"]].sum().rename_axis("interaction").reset_index(name="count")
st.plotly_chart(px.pie(breakdown,names="interaction",values="count",hole=.45,title="Share of total interactions"),use_container_width=True)
st.subheader("Filtered post data")
st.dataframe(filtered.sort_values("engagement_rate",ascending=False),use_container_width=True,hide_index=True)
st.download_button("Download filtered data (CSV)",filtered.to_csv(index=False).encode("utf-8"),"filtered_social_media_posts.csv","text/csv")
st.caption("Dataset included with this project is synthetic and intended for demonstration/academic analysis, not as real platform analytics.")
