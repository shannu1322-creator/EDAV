# Social Media Engagement Pattern Analysis

An Exploratory Data Analysis (EDA) project that studies how social platform, content format, posting day and posting hour relate to audience engagement. It includes a reproducible Python analysis pipeline and an interactive Streamlit dashboard.

## Project structure

```text
social_media_engagement_analysis/
├── app.py                         # Interactive Streamlit dashboard
├── data/
│   └── social_media_posts.csv     # Included demonstration dataset (synthetic)
├── outputs/                       # Generated charts and summary CSVs
├── src/
│   └── analysis.py                # Cleaning, metrics, summaries and charts
├── requirements.txt
└── README.md
```

## Questions explored

- Which platform has the highest average engagement rate?
- Which content format performs best?
- How does engagement vary by day of week and posting hour?
- What proportion of interactions comes from likes, comments, shares and saves?
- How are reach, impressions and engagement metrics related?

## Engagement metric

`engagements = likes + comments + shares + saves`

`engagement_rate (%) = engagements / reach × 100`

This project uses reach as the denominator. When comparing with external reports, check their formula because some use followers or impressions instead.

## Dataset

The included CSV has 1,500 synthetic post records with platform, content type, date/time, audience size, reach, impressions and interaction counts. It is generated for demonstration and reproducibility; it is **not scraped from Instagram, YouTube, X, Facebook or TikTok** and must not be represented as real-world platform performance. Replace it with an appropriately licensed dataset to conduct empirical research.

### Columns

| Column | Description |
|---|---|
| post_id | Unique post identifier |
| post_date, post_hour, day_of_week | Publishing date and time features |
| platform, content_type | Platform and post format |
| followers | Account follower count at posting time |
| reach, impressions | Audience reach and total displays |
| likes, comments, shares, saves | Interaction counts |
| hashtag_count | Number of hashtags |
| caption_sentiment | Synthetic caption sentiment category |
| engagements | Sum of likes, comments, shares and saves |
| engagement_rate | Engagements divided by reach, in percent |

## Setup

Python 3.9 or newer is recommended.

```bash
# Optional: create and activate a virtual environment
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

pip install -r requirements.txt
```

## Run the analysis

From the project root:

```bash
python src/analysis.py
```

Charts and summary tables are written to `outputs/`.

## Launch the dashboard

```bash
streamlit run app.py
```

Use the sidebar to filter by platform, content type and date range. Download the filtered records as CSV from the dashboard.

## Suggested interpretation / limitations

- A higher engagement rate is not automatically proof that a platform or format is better; audience size, niche, paid promotion and content quality can confound comparisons.
- The included data is synthetic, so observed rankings and peaks are illustrative only.
- Correlation does not establish causation.
- Posting-time recommendations should be validated against the target account's own historical data and local audience time zone.
- Real social-platform APIs have access, privacy, rate-limit and terms-of-service constraints. Use only data you are authorized to analyze.

## Technologies

Python, pandas, NumPy, Matplotlib, Seaborn, Plotly and Streamlit.
